
**StackImpact** is a production-grade performance profiler for production and development environments.

The [stackimpact.com](https://stackimpact.com/) website is built with awesome Hugo. Grunt is used for CSS minification and bundling.