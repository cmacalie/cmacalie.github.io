**Quiply** is an employee communications app enabling mobile collaboration across an entire organization.
Our customers get their own branded app enabling them to communicate fast and effectively with all employees, also non-desk and shift workers. 

As the Quiply app's build process is based on **Gulp**, we have started to build our company and product website using **Gulp + Hugo** which is super-fast and gives us exactly the flexibility we need.
