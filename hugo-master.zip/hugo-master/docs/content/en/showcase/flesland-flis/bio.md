
A business page for Flesland Flis AS. A Norwegian Tiler located in Bergen.

The page is designed and developed by Sindre Gusdal:

* [Absoluttweb AS](http://www.absoluttweb.no)
* [Sindre Gusdal](https://www.linkedin.com/in/sindregusdal/)

