
[Camping Arolla](http://www.camping-arolla.com/) is located in the heart of the Swiss Alps, at an altitude of 1.950 meters.

The site is built by:

* [Didier Divinerites](https://github.com/divinerites)
