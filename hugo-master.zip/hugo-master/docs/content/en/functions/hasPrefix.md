---
title: hasprefix
linktitle: hasPrefix
description: Tests whether a string begins with prefix.
godocref:
date: 2017-02-01
publishdate: 2017-02-01
lastmod: 2017-02-01
categories: [functions]
menu:
  docs:
    parent: "functions"
keywords: []
signature: ["hasPrefix STRING PREFIX"]
workson: []
hugoversion:
relatedfuncs: []
deprecated: false
aliases: []
---

* `{{ hasPrefix "Hugo" "Hu" }}` → true
