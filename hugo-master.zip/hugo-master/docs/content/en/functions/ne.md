---
title: ne
linktitle: ne
description: Returns the boolean truth of arg1 != arg2.
godocref:
date: 2017-07-26
publishdate: 2017-07-26
lastmod: 2017-07-26
categories: [functions]
menu:
  docs:
    parent: "functions"
keywords: [operators,logic]
signature: ["ne ARG1 ARG2"]
workson: []
hugoversion:
relatedfuncs: []
deprecated: false
aliases: []
---


```
{{ if ne .Section "blog" }}current{{ end }}
```
