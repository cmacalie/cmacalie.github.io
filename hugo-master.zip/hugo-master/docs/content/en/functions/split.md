---
title: split
# linktitle: split
description: splits a string into substrings separated by a delimiter
godocref:
date: 2017-02-01
publishdate: 2017-02-01
lastmod: 2017-02-01
categories: [functions]
menu:
  docs:
    parent: "functions"
keywords: [strings]
signature: ["split STRING DELIM"]
workson: []
hugoversion:
relatedfuncs: []
deprecated: false
aliases: []
---

* `{{split "tag1,tag2,tag3" "," }}` → ["tag1" "tag2" "tag3"]


