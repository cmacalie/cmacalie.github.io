---
title: Maintenance
description: Some lists useful for the maintenance of the Hugo docs site.
date: 2018-02-09
categories: [maintenance]
keywords: [maintenance]
menu:
  docs:
    weight: 200
slug:
aliases: []
toc: true
---

