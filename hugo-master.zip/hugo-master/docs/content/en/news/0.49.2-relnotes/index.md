---
date: 2018-10-11
title: "Hugo 0.49.2: One Bug Fix"
description: "Fixes a type issue in append and Scratch.Add"
categories: ["Releases"]
images:
- images/blog/hugo-bug-poster.png
---

This fixes one regression from Hugo `0.42.1`:

* Fix type checking in Append [2159d77f](https://github.com/gohugoio/hugo/commit/2159d77f368eb1f78e51dd94133554f88052d85f) [@bep](https://github.com/bep) [#5303](https://github.com/gohugoio/hugo/issues/5303)





