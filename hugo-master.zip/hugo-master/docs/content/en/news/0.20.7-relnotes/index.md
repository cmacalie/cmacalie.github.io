---
date: 2017-05-03T17:53:58-04:00
categories: ["Releases"]
description: "This just fixes an issue with the release scripts, no change in the binaries"
link: ""
title: "Hugo 0.20.7"
draft: false
author: bep
aliases: [/0-20-7/]
---

This just fixes an issue with the release scripts, no change in the binaries.


Hugo now has:

* 16782&#43; [stars](https://github.com/gohugoio/hugo/stargazers)
* 458&#43; [contributors](https://github.com/gohugoio/hugo/graphs/contributors)
* 156&#43; [themes](http://themes.gohugo.io/)

## Fix

* Push the tag before goreleaser is run [3682bf52](https://github.com/gohugoio/hugo/commit/3682bf527989e86d9da32d76809306cb576383e8) [@bep](https://github.com/bep) [#3405](https://github.com/gohugoio/hugo/issues/3405) 