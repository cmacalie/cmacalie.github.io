
---
date: 2018-01-03
title: "Hugo 0.32.2: One bugfix"
description: "Fixes one issue with publishing of processed images when no cache."
categories: ["Releases"]
images:
- images/blog/hugo-bug-poster.png

---

	

This is a bug-fix release with one important fix.


* Handle publish of processed images to /public on fresh build with no image cache in /resources (as reported by one person in a Netlify build) [196da49c](https://github.com/gohugoio/hugo/commit/196da49c9d906fbae6d389fdd32b80c27cb38de4) [@bep](https://github.com/bep) [#4213](https://github.com/gohugoio/hugo/issues/4213)






