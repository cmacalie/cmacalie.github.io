
---
date: 2018-04-25
title: "Hugo 0.40.1: One Bug Fix"
description: "Fixes some shortcode vs .Content corner cases."
categories: ["Releases"]
images:
- images/blog/hugo-bug-poster.png

---

	

This release fixes some shortcode vs `.Content` corner cases introduced in Hugo `0.40` [288c3964](https://github.com/gohugoio/hugo/commit/288c39643906b4194a0a6acfbaf87cb0fbdeb361) [@bep](https://github.com/bep) [#4632](https://github.com/gohugoio/hugo/issues/4632)[#4664](https://github.com/gohugoio/hugo/issues/4664).





