---
date: 2013-07-05T04:22:00Z
description: "The first public release of Hugo."
title: "Hugo 0.7"
categories: ["Releases"]
---

As the first public release here's a bit about what Hugo can do so far:

- **0.7.0** July 4, 2013
  - Hugo now includes a simple server
  - First public release
- **0.6.0** July 2, 2013
  - Hugo includes an [example documentation site](http://hugo.spf13.com) which it builds
- **0.5.0** June 25, 2013
  - Hugo is quite usable and able to build [spf13.com](http://spf13.com)
