
---
date: 2017-10-19T12:00:00+02:00
title: "Hugo 0.30.2: One More Bugfix"
description: "Fixes Fast Render mode when having sub-path in `baseURL`."
categories: ["Releases"]
images:
- images/blog/hugo-bug-poster.png
---
This release fixes Fast Render mode with sub-path in baseURL [31641033](https://github.com/gohugoio/hugo/commit/3164103310fbca1211cfa9ce4a5eb7437854b6ad) [@bep](https://github.com/bep) [#3981](https://github.com/gohugoio/hugo/issues/3981).




