
---
date: 2018-06-28
title: "Hugo 0.42.2: One Bug Fix"
description: "Hugo 0.42.2 fixes server reload on config changes."
categories: ["Releases"]
images:
- images/blog/hugo-bug-poster.png

---


 This release fixes broken server-reload on config changes. This is a regression from Hugo `0.42`. [3a7706b0](https://github.com/gohugoio/hugo/commit/3a7706b069107e5fa6112b3f7ce006f16867cb38) [@bep](https://github.com/bep) [#4878](https://github.com/gohugoio/hugo/issues/4878)





