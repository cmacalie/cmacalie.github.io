---
date: 2017-04-13T13:53:58-04:00
categories: ["Releases"]
description: "Hugo 0.20.1 is a bug fix release, fixing some important regressions introduced in 0.20"
link: ""
title: "Hugo 0.20.1"
draft: false
author: bep
aliases: [/0-20-1/]
---

*   Fix logic for base template in work dir vs in the theme [#3323](//github.com/gohugoio/hugo/issues/3323)
*   camelCased templates (partials, shortcodes etc.) not found [#3333](//github.com/gohugoio/hugo/issues/3333)
*   Live-reload fails with `_index.md` with paginator [#3315](//github.com/gohugoio/hugo/issues/3315)
*   `rssURI` WARNING always shown [#3319](//github.com/gohugoio/hugo/issues/3319)