
---
date: 2017-11-27
title: "Hugo 0.31.1: One Bugfix!"
description: "Fixes broken `--appendPort=false`."
categories: ["Releases"]
images:
- images/blog/hugo-bug-poster.png

---
	
This is a bug-fix release with one important bug fix:

* Fix broken `--appendPort=false` [8afd7d9c](https://github.com/gohugoio/hugo/commit/8afd7d9ceb0d168300e3399c6e87a355a88c9a28) [@bep](https://github.com/bep) [#4111](https://github.com/gohugoio/hugo/issues/4111)





