---
date: 2017-04-25T17:53:58-04:00
categories: ["Releases"]
description: ""
link: ""
title: "Hugo 0.20.5"
draft: false
author: bep
aliases: [/0-20-5/]
---

This is a bug-fix release which fixes the version number of `0.20.4` (which wrongly shows up as `0.21-DEV`) ([#3388](https://github.com/gohugoio/hugo/issues/3388)).