---
title: "Hugo News"
aliases: [/release-notes/]
---
